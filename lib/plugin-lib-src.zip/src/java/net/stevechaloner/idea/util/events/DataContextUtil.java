/*
 * Copyright 2007 Steve Chaloner
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package net.stevechaloner.idea.util.events;

import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.editor.Editor;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Utility class for extracting objects from the {@link DataContext}.
 * @author Steve Chaloner
 */
public class DataContextUtil
{
    /**
     * Gets all open files.
     *
     * @param dataContext the data context of this operation
     * @return a list of open files
     */
    @NotNull
    public static List<VirtualFile> getVirtualFiles(@NotNull DataContext dataContext)
    {
        return new ArrayList<VirtualFile>(Arrays.asList((VirtualFile[]) dataContext.getData(DataConstants.VIRTUAL_FILE_ARRAY)));
    }

    /**
     * Gets the project this operation occurred in.
     *
     * @param dataContext the data context of this operation
     * @return the project
     */
    public static Project getProject(@NotNull DataContext dataContext)
    {
        return (Project) dataContext.getData(DataConstants.PROJECT);
    }

    /**
     * Gets the active editor.
     *
     * @param dataContext the data context of this operation
     * @return the active editor
     */
    public static Editor getEditor(@NotNull DataContext dataContext)
    {
        return (Editor) dataContext.getData(DataConstants.EDITOR);
    }

    /**
     * Gets the extension of the selected file.
     *
     * @param dataContext the data context of this operation
     * @return the extension, or null if no file is selected
     */
    @Nullable
    public static String getFileExtension(@NotNull DataContext dataContext)
    {
        VirtualFile file = (VirtualFile) dataContext.getData(DataConstants.VIRTUAL_FILE);
        return file == null ? null : file.getExtension();
    }

    /**
     * Gets the selected file.
     *
     * @param dataContext the data context of this operation
     * @return the file, or null if no file is selected
     */
    @Nullable
    public static VirtualFile getFile(@NotNull DataContext dataContext)
    {
        return (VirtualFile) dataContext.getData(DataConstants.VIRTUAL_FILE);
    }
}
